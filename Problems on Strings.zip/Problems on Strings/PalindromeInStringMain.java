import java.util.Scanner;
public class PalindromeInStringMain{
  public static void main(String[] args){
    PalindromeString a=new PalindromeString();
    a.palindrome();
  }
} 
class PalindromeString{
  public void palindrome(){
    
    StringBuffer sb=new StringBuffer();
    System.out.println("enetr a stri ng");
    
    
    
    System.out.println(sb.reverse());
    
  }
}